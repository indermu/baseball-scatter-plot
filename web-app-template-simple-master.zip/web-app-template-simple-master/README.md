web-app-template-simple
=======================

A simple web app template with jQuery, and Bootstrap.  | Mizzou Workshop - Oct. 2014
